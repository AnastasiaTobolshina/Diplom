<?php

use yii\bootstrap5\Html;

?>
<div class="admin-default-index">
    <h3>Панель администратора</h3>
    <p>
       <?= Html::a('Управление товарами', ['product/index'], ['class' => 'btn btn-outline-success']) ?>
       <?= Html::a('Управление заказами', ['order/index'], ['class' => 'btn btn-success']) ?>
    </p>
    
</div>