<?php

use yii\helpers\Url;
use yii\helpers\Html;

use yii\bootstrap5\Alert;
use yii\widgets\ListView;
use yii\grid\ActionColumn;
/** @var yii\web\View $this */
/** @var app\modules\account\models\OrderSearch $searchModel */
/** @var yii\data\ActiveDataProvider $dataProvider */

$this->params['breadcrumbs'][] = $this->title;
?>
<div class="product-index">

    <h3><?= Html::encode($this->title) ?></h3>
    
    <?= ListView::widget([
        'dataProvider' => $dataProvider,
        'layout' => "\n<div class=\"d-flex justify-content-between flex-wrap h-100\">{items}</div>\n<div class=\"mt-3 d-flex align-items-center justify-content-center\">{pager}</div>",
        'itemOptions' => ['class' => 'item'],
        'itemView' => 'item',
    ]) ?>



</div>
